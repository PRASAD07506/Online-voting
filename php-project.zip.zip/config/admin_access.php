<?php

define('ADMIN_REGISTRATION_CODE', 'Admin123');
