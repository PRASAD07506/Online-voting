<?php
mysqli_report(MYSQLI_REPORT_OFF);

$conn = @new mysqli(
    "sql206.infinityfree.com",
    "if0_41575875",
    "Prasad@2004",
    "if0_41575875_voting",
    3306
);

if ($conn->connect_errno) {
    die("Database connection failed. Check your InfinityFree database settings.");
}

$conn->set_charset('utf8mb4');
