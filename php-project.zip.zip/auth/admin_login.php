<?php
session_start();

if(isset($_SESSION['user_id'])){
    $destination = (isset($_SESSION['role']) && $_SESSION['role'] === 'admin')
        ? '../admin/dashboard.php'
        : '../user/dashboard.php';
    header("Location: " . $destination);
    exit;
}

include("../config/db.php");
require_once("auth_helpers.php");

$error = '';

if(isset($_POST['login'])){
    $email = trim($_POST['email'] ?? '');
    $password = $_POST['password'] ?? '';
    $user = find_user_by_email($conn, $email);

    if(!$user || $user['role'] !== 'admin' || !password_verify($password, $user['password'])){
        $error = "Invalid admin email or password.";
    } elseif ($user['status'] === 'blocked') {
        $error = "This admin account is blocked.";
    } else {
        login_user_session($user);
        header("Location: ../admin/dashboard.php");
        exit;
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Login</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="../style.css">
</head>
<body class="app-shell">
<div class="container min-vh-100 d-flex justify-content-center align-items-center py-5">
    <div class="card glass-card auth-card elevate-hover" style="max-width: 520px; width: 100%;">
        <div class="card-body p-4 p-md-5">
            <div class="text-center mb-4">
                <span class="brand-badge mb-3">Admin Login</span>
                <h3 class="mb-2">Administrator access</h3>
                <p class="text-muted mb-0">Login as admin to control elections and review requests.</p>
            </div>

            <?php if($error): ?>
                <div class="alert alert-danger"><?= htmlspecialchars($error) ?></div>
            <?php endif; ?>

            <form method="POST">
                <div class="mb-3">
                    <input type="email" name="email" class="form-control" placeholder="Admin email" value="<?= isset($_POST['email']) ? htmlspecialchars($_POST['email']) : '' ?>" required>
                </div>
                <div class="mb-3">
                    <div class="input-group">
                        <input type="password" name="password" id="adminLoginPassword" class="form-control" placeholder="Password" required>
                        <button type="button" class="btn btn-outline-secondary" data-toggle-password="#adminLoginPassword">Show</button>
                    </div>
                </div>

                <button class="btn btn-dark w-100 py-2" name="login">Admin Login</button>
            </form>

            <div class="text-center mt-4">
                <a href="admin_register.php" class="text-decoration-none fw-semibold">Admin Register</a>
            </div>
            <div class="text-center mt-2">
                <a href="user_login.php" class="text-decoration-none">Go to User Login</a>
            </div>
        </div>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
<script>
document.querySelectorAll('[data-toggle-password]').forEach(function (button) {
    button.addEventListener('click', function () {
        var input = document.querySelector(button.getAttribute('data-toggle-password'));
        var isPassword = input.type === 'password';
        input.type = isPassword ? 'text' : 'password';
        button.textContent = isPassword ? 'Hide' : 'Show';
    });
});
</script>
</body>
</html>
