<?php
session_start();
if(!isset($_SESSION['role']) || $_SESSION['role'] !== 'admin'){
    header("Location: ../auth/login.php");
    exit;
}

include("../config/db.php");
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Add Candidate</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body class="bg-light">
    <div class="container py-5">
        <div class="row justify-content-center">
            <div class="col-md-7 col-lg-5">
                <div class="card shadow-sm border-0">
                    <div class="card-body p-4">
                        <div class="d-flex justify-content-between align-items-center mb-4">
                            <h1 class="h4 mb-0">Add Candidate</h1>
                            <a href="dashboard.php" class="btn btn-sm btn-outline-secondary">Back</a>
                        </div>

                        <form method="POST" class="row g-3">
                            <div class="col-12">
                                <label for="name" class="form-label">Candidate Name</label>
                                <input type="text" id="name" name="name" class="form-control" required>
                            </div>
                            <div class="col-12">
                                <label for="party" class="form-label">Party</label>
                                <input type="text" id="party" name="party" class="form-control" required>
                            </div>
                            <div class="col-12">
                                <button type="submit" name="add" class="btn btn-primary w-100">Add Candidate</button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>

<?php
if(isset($_POST['add'])){
    $name = $_POST['name'];
    $party = $_POST['party'];

    $conn->query("INSERT INTO candidates(name,party) VALUES('$name','$party')");
    echo "<script>alert('Candidate added successfully'); window.location='add_candidates.php';</script>";
}
?>
