<?php
session_start();

if(!isset($_SESSION['user_id'])){
    header("Location: ../auth/login.php");
    exit;
}

include("../config/db.php");
require_once("../config/face_helpers.php");
require_once("../config/election_helpers.php");

$user_id = (int) $_SESSION['user_id'];
$user = $conn->query("SELECT * FROM users WHERE id=$user_id")->fetch_assoc();
$settings = get_election_settings($conn);

if(!empty($user['has_voted'])){
    header("Location: dashboard.php");
    exit;
}

if(!face_image_exists($user_id)){
    header("Location: enroll_face.php");
    exit;
}

$faceVerified = isset($_SESSION['face_verified_user'], $_SESSION['face_verified_at'])
    && (int) $_SESSION['face_verified_user'] === $user_id
    && (int) $_SESSION['face_verified_at'] >= (time() - 600);

if(!$faceVerified){
    header("Location: verify_face.php");
    exit;
}

if(!is_election_open($settings)){
    unset($_SESSION['vote_deadline_at']);
    header("Location: dashboard.php");
    exit;
}

$voteDuration = max(30, (int) ($settings['vote_duration_seconds'] ?? 120));
$electionEndAt = !empty($settings['ends_at']) ? strtotime($settings['ends_at']) : null;

if(empty($_SESSION['vote_deadline_at']) || (int) $_SESSION['vote_deadline_at'] < time()){
    $deadline = time() + $voteDuration;
    if($electionEndAt) {
        $deadline = min($deadline, $electionEndAt);
    }
    $_SESSION['vote_deadline_at'] = $deadline;
}

$deadlineAt = (int) $_SESSION['vote_deadline_at'];
$timeRemaining = max(0, $deadlineAt - time());
$error = '';

if(isset($_POST['vote'])){
    if(time() > $deadlineAt){
        $error = "Your voting timer expired. Please restart verification to continue.";
        unset($_SESSION['vote_deadline_at'], $_SESSION['face_verified_at'], $_SESSION['face_verified_user']);
    } elseif(!is_election_open($settings)) {
        $error = "Voting is no longer active.";
        unset($_SESSION['vote_deadline_at']);
    } else {
    $cid = (int) $_POST['candidate_id'];

    $conn->query("INSERT INTO votes(user_id,candidate_id) VALUES($user_id,$cid)");
    $conn->query("UPDATE candidates SET votes=votes+1 WHERE id=$cid");
    $conn->query("UPDATE users SET has_voted=1 WHERE id=$user_id");
    unset($_SESSION['vote_deadline_at']);

    header("Location: dashboard.php");
    exit;
    }
}

$result = $conn->query("SELECT * FROM candidates");
?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Vote</title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
<link rel="stylesheet" href="../style.css">
</head>

<body class="app-shell">

<nav class="navbar navbar-dark bg-dark nav-shadow">
    <div class="container">
        <span class="navbar-brand">Cast Your Vote</span>
        <a href="dashboard.php" class="btn btn-outline-light">Back</a>
    </div>
</nav>

<div class="container page-section">
    <div class="row justify-content-center">
        <div class="col-lg-8">
            <div class="card glass-card">
                <div class="card-body p-4 p-md-5">
                    <div class="d-flex justify-content-between align-items-center flex-wrap gap-2 mb-4">
                        <div>
                            <h3 class="mb-1">Vote for your candidate</h3>
                            <p class="text-muted mb-0">Select one candidate and submit your ballot once.</p>
                        </div>
                        <span class="badge text-bg-primary">One vote only</span>
                    </div>

                    <?php if($error): ?>
                        <div class="alert alert-danger"><?= htmlspecialchars($error) ?></div>
                    <?php endif; ?>

                    <div class="alert alert-warning d-flex justify-content-between align-items-center flex-wrap gap-2">
                        <span>This ballot closes when the timer reaches zero.</span>
                        <strong id="voteCountdown" data-deadline="<?= $deadlineAt ?>">--:--</strong>
                    </div>

                    <form method="POST">
                        <div class="row g-3 mb-4">
                            <?php while($row = $result->fetch_assoc()){ ?>
                                <div class="col-md-6">
                                    <div class="vote-option">
                                        <input type="radio" id="candidate-<?= $row['id'] ?>" name="candidate_id" value="<?= $row['id'] ?>" required>
                                        <label for="candidate-<?= $row['id'] ?>" class="h-100">
                                            <span class="d-block fw-semibold mb-1"><?= htmlspecialchars($row['name']) ?></span>
                                            <span class="text-muted"><?= htmlspecialchars($row['party']) ?></span>
                                        </label>
                                    </div>
                                </div>
                            <?php } ?>
                        </div>

                        <div class="d-flex justify-content-between align-items-center flex-wrap gap-3">
                            <div id="selectedCandidate" class="text-muted">No candidate selected yet.</div>
                            <button class="btn btn-success px-4" name="vote" id="voteButton" disabled>Submit Vote</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
<script>
var radios = document.querySelectorAll('input[name="candidate_id"]');
var voteButton = document.getElementById('voteButton');
var selectedCandidate = document.getElementById('selectedCandidate');
var voteCountdown = document.getElementById('voteCountdown');

radios.forEach(function (radio) {
    radio.addEventListener('change', function () {
        var label = document.querySelector('label[for="' + radio.id + '"] .fw-semibold');
        selectedCandidate.textContent = 'Selected: ' + label.textContent;
        voteButton.disabled = false;
    });
});

if (voteCountdown) {
    var deadline = parseInt(voteCountdown.getAttribute('data-deadline'), 10) * 1000;

    var renderCountdown = function () {
        var remaining = Math.max(0, Math.floor((deadline - Date.now()) / 1000));
        var minutes = String(Math.floor(remaining / 60)).padStart(2, '0');
        var seconds = String(remaining % 60).padStart(2, '0');
        voteCountdown.textContent = minutes + ':' + seconds;

        if (remaining <= 0) {
            voteButton.disabled = true;
            selectedCandidate.textContent = 'Voting time expired. Reloading...';
            window.location.href = 'dashboard.php';
        }
    };

    renderCountdown();
    window.setInterval(renderCountdown, 1000);
}
</script>
</body>
</html>
