<?php
session_start();

if(!isset($_SESSION['user_id'])){
    header("Location: ../auth/login.php");
    exit;
}

include("../config/db.php");
require_once("../config/candidate_request_helpers.php");

$user_id = (int) $_SESSION['user_id'];
$user = $conn->query("SELECT * FROM users WHERE id = $user_id")->fetch_assoc();
$error = '';
$success = '';

ensure_candidate_requests_table($conn);

$existingRequestResult = $conn->query("SELECT * FROM candidate_requests WHERE user_id = $user_id LIMIT 1");
$existingRequest = $existingRequestResult ? $existingRequestResult->fetch_assoc() : null;

if(isset($_POST['submit_request']) && !$existingRequest){
    $candidateName = trim($_POST['candidate_name']);
    $partyName = trim($_POST['party_name']);
    $manifesto = trim($_POST['manifesto']);

    if($candidateName === '' || $partyName === ''){
        $error = 'Candidate name and party name are required.';
    } else {
        $stmt = $conn->prepare("
            INSERT INTO candidate_requests (user_id, candidate_name, party_name, manifesto)
            VALUES (?, ?, ?, ?)
        ");
        $stmt->bind_param("isss", $user_id, $candidateName, $partyName, $manifesto);

        if($stmt->execute()){
            $success = 'Your candidate request has been sent to the admin for review.';
            $existingRequest = $conn->query("SELECT * FROM candidate_requests WHERE user_id = $user_id LIMIT 1")->fetch_assoc();
        } else {
            $error = 'We could not send your request right now.';
        }

        $stmt->close();
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Candidate Request</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="../style.css">
</head>
<body class="app-shell">
<nav class="navbar navbar-dark bg-dark nav-shadow">
    <div class="container">
        <span class="navbar-brand">Candidate Request</span>
        <a href="dashboard.php" class="btn btn-outline-light">Back</a>
    </div>
</nav>

<div class="container page-section">
    <div class="row justify-content-center">
        <div class="col-lg-8">
            <div class="card glass-card">
                <div class="card-body p-4 p-md-5">
                    <span class="brand-badge mb-3">Candidate Access</span>
                    <h1 class="h3 mb-2">Request admin approval to become a candidate</h1>
                    <p class="text-muted mb-4">Submit your details once. The admin will review and either approve or reject the request.</p>

                    <?php if($error): ?>
                        <div class="alert alert-danger"><?= htmlspecialchars($error) ?></div>
                    <?php endif; ?>
                    <?php if($success): ?>
                        <div class="alert alert-success"><?= htmlspecialchars($success) ?></div>
                    <?php endif; ?>

                    <?php if($existingRequest): ?>
                        <div class="alert <?= $existingRequest['status'] === 'approved' ? 'alert-success' : ($existingRequest['status'] === 'rejected' ? 'alert-danger' : 'alert-warning') ?>">
                            Request status: <strong><?= htmlspecialchars(ucfirst($existingRequest['status'])) ?></strong>
                        </div>
                        <div class="soft-stat mb-3">
                            <span class="text-muted">Candidate Name</span>
                            <strong><?= htmlspecialchars($existingRequest['candidate_name']) ?></strong>
                        </div>
                        <div class="soft-stat mb-3">
                            <span class="text-muted">Party</span>
                            <strong><?= htmlspecialchars($existingRequest['party_name']) ?></strong>
                        </div>
                        <div class="soft-stat">
                            <span class="text-muted">Manifesto</span>
                            <strong><?= htmlspecialchars($existingRequest['manifesto'] ?: 'No manifesto provided') ?></strong>
                        </div>
                    <?php else: ?>
                        <form method="POST" class="row g-3">
                            <div class="col-12">
                                <label for="candidate_name" class="form-label">Candidate name</label>
                                <input type="text" id="candidate_name" name="candidate_name" class="form-control" value="<?= htmlspecialchars($user['name'] ?? '') ?>" required>
                            </div>
                            <div class="col-12">
                                <label for="party_name" class="form-label">Party name</label>
                                <input type="text" id="party_name" name="party_name" class="form-control" required>
                            </div>
                            <div class="col-12">
                                <label for="manifesto" class="form-label">Manifesto</label>
                                <textarea id="manifesto" name="manifesto" class="form-control" rows="5" placeholder="Write a short description of your campaign"></textarea>
                            </div>
                            <div class="col-12">
                                <button type="submit" name="submit_request" class="btn btn-primary">Send Request</button>
                            </div>
                        </form>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
