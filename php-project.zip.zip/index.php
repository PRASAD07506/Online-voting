<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Voting System</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="style.css">
</head>
<body class="app-shell">
    <div class="container min-vh-100 d-flex align-items-center">
        <div class="row justify-content-center w-100">
            <div class="col-md-8 col-lg-6">
                <div class="card hero-card elevate-hover">
                    <div class="card-body p-5 text-center">
                        <span class="brand-badge mb-3">Online Voting System</span>
                        <h1 class="h2 mb-3">Welcome to the voting portal</h1>
                        <p class="text-muted mb-4">
                            Sign in to cast your vote or create an account to participate.
                        </p>
                        <div class="d-grid gap-3 d-sm-flex justify-content-sm-center">
                            <a href="auth/user_login.php" class="btn btn-primary btn-lg px-4">User Login</a>
                            <a href="auth/register.php" class="btn btn-outline-primary btn-lg px-4">Register</a>
                            <a href="auth/admin_login.php" class="btn btn-dark btn-lg px-4">Admin Login</a>
                            <a href="auth/admin_register.php" class="btn btn-outline-dark btn-lg px-4">Admin Register</a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
